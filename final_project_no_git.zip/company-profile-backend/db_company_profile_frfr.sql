-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_company_profile
CREATE DATABASE IF NOT EXISTS `db_company_profile` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_company_profile`;

-- Dumping structure for table db_company_profile.commodities
CREATE TABLE IF NOT EXISTS `commodities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_sold` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.commodities: ~0 rows (approximately)
INSERT INTO `commodities` (`id`, `name`, `origin`, `grade`, `description`, `total_sold`, `created_at`, `updated_at`) VALUES
	(1, 'Petis Udang', 'Cirebon', 'Grade A', 'Udang', 85, NULL, NULL),
	(2, 'Bawang Merah', 'Brebes', 'Super', 'Bawang merah', 120, NULL, NULL),
	(3, 'Kacang Tanah', 'Majalengka', 'Grade A', 'Kacang Tanah', 60, NULL, NULL),
	(4, 'Ebi', 'Indramayu', 'Premium', 'Ebi', 90, NULL, NULL);

-- Dumping structure for table db_company_profile.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table db_company_profile.layanans
CREATE TABLE IF NOT EXISTS `layanans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_layanan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `total_sold` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.layanans: ~0 rows (approximately)
INSERT INTO `layanans` (`id`, `nama_layanan`, `deskripsi`, `gambar`, `created_at`, `updated_at`, `total_sold`) VALUES
	(1, 'Petis Udang', 'Petis udang autentik khas Cirebon dengan cita rasa kuat dan aroma khas yang menjadi bahan baku unggulan untuk industri kuliner, pabrik bumbu, dan produsen makanan olahan.', 'komoditas/G5NuLXaOimZ03ohZxhLEXDNXBTt36ZUDQ2rMWVuG.jpg', '2026-05-24 08:52:58', '2026-05-24 06:44:02', 85),
	(2, 'Bawang Merah', 'Bawang merah segar pilihan dari sentra produksi Brebes dan Cirebon. Cocok untuk kebutuhan industri kuliner, hotel & restoran, serta pengolahan bumbu skala besar.', 'komoditas/RbHMclS9wL8tjRkGRCOPak5TWykhjjcX7UCPAZPu.jpg', '2026-05-24 08:53:00', '2026-05-24 06:43:53', 120),
	(3, 'Ebi', 'Ebi atau udang kering berkualitas premium dari nelayan pesisir utara Jawa. Bahan penting untuk bumbu penyedap, kerupuk udang, dan berbagai produk kuliner Nusantara.\r\n\r\n✓\r\nDikeringkan secara alami\r\n✓\r\nAroma kuat & harum\r\n✓\r\nUkuran seragam\r\n✓\r\nKemasan vakum tersedia', 'komoditas/6W69YND8LnrF6oK1nLEKnF8Oc1SgRy1jxTk3i5ED.jpg', '2026-05-24 06:36:39', '2026-05-24 06:37:53', NULL),
	(4, 'Kacang Tanah', 'Kacang tanah lokal berkualitas tinggi dalam berbagai bentuk olahan. Menjadi bahan baku pilihan untuk industri snack, produsen kacang goreng, dan pabrik bumbu kacang.\r\n\r\n✓\r\nUkuran seragam & besar\r\n✓\r\nKadar aflatoksin terkontrol\r\n✓\r\nTersedia varian kupas & kulit\r\n✓\r\nMOQ fleksibel per kuintal', 'komoditas/4cX9yDOvwVqyT7NwaB8FAtiJ4rfJ8Ffo4ZbH5gho.jpg', '2026-05-24 06:44:43', '2026-05-24 06:44:43', NULL);

-- Dumping structure for table db_company_profile.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.migrations: ~0 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2026_05_24_083414_create_layanans_table', 1),
	(6, '2026_05_24_125937_create_commodities_table', 2),
	(7, '2026_05_24_131720_create_sales_histories_table', 3);

-- Dumping structure for table db_company_profile.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.password_reset_tokens: ~0 rows (approximately)

-- Dumping structure for table db_company_profile.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table db_company_profile.sales_histories
CREATE TABLE IF NOT EXISTS `sales_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `layanan_id` bigint unsigned NOT NULL,
  `year` int NOT NULL,
  `volume_sold` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_histories_layanan_id_foreign` (`layanan_id`),
  CONSTRAINT `sales_histories_layanan_id_foreign` FOREIGN KEY (`layanan_id`) REFERENCES `layanans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.sales_histories: ~6 rows (approximately)
INSERT INTO `sales_histories` (`id`, `layanan_id`, `year`, `volume_sold`, `created_at`, `updated_at`) VALUES
	(1, 1, 2024, 40, NULL, NULL),
	(2, 1, 2025, 85, NULL, NULL),
	(3, 1, 2026, 100, NULL, NULL),
	(4, 2, 2024, 60, NULL, NULL),
	(5, 2, 2025, 90, NULL, NULL),
	(6, 2, 2026, 120, NULL, NULL),
	(7, 3, 2024, 75, '2026-05-24 06:36:55', '2026-05-24 06:37:01'),
	(8, 3, 2025, 75, '2026-05-24 06:37:14', '2026-05-24 06:37:14'),
	(9, 3, 2026, 70, '2026-05-24 06:37:20', '2026-05-24 06:37:20'),
	(10, 4, 2024, 65, '2026-05-24 06:44:58', '2026-05-24 06:44:58'),
	(11, 4, 2025, 70, '2026-05-24 06:45:07', '2026-05-24 06:45:07'),
	(12, 4, 2026, 55, '2026-05-24 06:45:21', '2026-05-24 06:45:21');

-- Dumping structure for table db_company_profile.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table db_company_profile.users: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
