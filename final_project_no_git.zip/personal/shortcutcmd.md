# Kumpulan Perintah (Shortcut Commands)

Dokumen ini berisi daftar perintah terminal yang sering digunakan selama proses *development* untuk backend (Laravel), frontend (Next.js), dan manajemen versi (Git).

## 🚀 1. Menjalankan Server Lokal (Development)

**Frontend (Next.js):**
```bash
cd company-profile-v1
npm run dev
```

**Backend (Laravel):**
```bash
cd company-profile-backend
php artisan serve
```

---

## 🛠️ 2. Perintah Backend (Laravel Artisan)

**Membersihkan Cache (Jika error tidak masuk akal atau baru mengubah `.env`):**
```bash
php artisan optimize:clear
```

**Menjalankan Migrasi & Seeder Database:**
```bash
php artisan migrate
php artisan db:seed
```

**Membuat File Baru (Controller, Model, dll):**
```bash
php artisan make:controller API/NamaController
php artisan make:model NamaModel -m
```

---

## 🌿 3. Manajemen Git (Git Flow)

**Mengecek Status File:**
```bash
git status
```

**Membuat Branch Baru & Langsung Pindah ke Branch Tersebut:**
```bash
git checkout -b nama-branch-baru
```

**Menyimpan Perubahan (Commit):**
```bash
git add .
git commit -m "pesan commit (contoh: feat: tambah fitur login)"
```

**Mengunggah Branch Baru ke GitHub/GitLab (Pertama Kali):**
```bash
git push -u origin nama-branch-baru
```

**Mengunggah Perubahan (Jika Branch Sudah Ada di Remote):**
```bash
git push
```

**Kembali ke Branch Utama (Main):**
```bash
git checkout main
```

**Memperbarui Kode dari GitHub ke Laptop:**
```bash
git pull origin main
```